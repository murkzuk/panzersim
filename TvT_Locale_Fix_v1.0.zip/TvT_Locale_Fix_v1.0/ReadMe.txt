T-34 vs Tiger - Locale Fix v1.0
------------------------------------

This patch restores missing localization files needed by the game to correctly display weapon names, action bindings, and mission objectives.

Without it, TvT throws missing string errors and some missions/scripts may not work correctly.

What's Included:
- Locale/eng.tsv : Basic English text strings covering weapons, actions, and mission objectives.

Installation Instructions:
1. Unzip the archive.
2. Copy the 'Locale' folder into your 'TvT\Data\' directory.
   (After copying, you should have TvT\Data\Locale\eng.tsv)
3. Overwrite if asked (the folder was probably missing anyway).
4. Restart the game.

Credits:
- Murkz
- GPT
